package id.ac.unand.ft.si.demokelasa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.List;

import id.ac.unand.ft.si.demokelasa.entity.MovieListResponse;
import id.ac.unand.ft.si.demokelasa.entity.ResultsItem;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private RecyclerView rvMovieList;
    MovieListAdapter movieListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMovieList = findViewById(R.id.rv_movie_list);
        movieListAdapter = new MovieListAdapter();
        rvMovieList.setAdapter(movieListAdapter);
        rvMovieList.setLayoutManager(new LinearLayoutManager(this));

        requestPermission();
        createNotificationChannel();
        populateData();
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                            return;
                        }
                        // Get new FCM registration token
                        String token = task.getResult();
                        Log.d(TAG, ">>>> " + token);
                    }
                });
    }


    public void populateData() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        MovieDbClient client = retrofit.create(MovieDbClient.class);

        Call<MovieListResponse> movieListResponseCall =
                client.getNowPlayingMovies("cf51c94af17e64e7a0b2fdf107a3dbc6");

        movieListResponseCall.enqueue(new Callback<MovieListResponse>() {
            @Override
            public void onResponse(Call<MovieListResponse> call, Response<MovieListResponse> response) {
                Toast.makeText(MainActivity.this, "Berhasil Gaes", Toast.LENGTH_SHORT).show();

                // Kode untuk memproses
                MovieListResponse movieListResponse = response.body();
                List<ResultsItem> movieList = movieListResponse.getResults();
                movieListAdapter.setListMovie(movieList);
            }

            @Override
            public void onFailure(Call<MovieListResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Gagal... 😢", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            CharSequence name = "Demo Notif A";
            String description = "Channel Demo Notifikasi Android PTB Kelas A";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel("kanal_ptb_a", name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);

        }
    }


    public void requestPermission() {
        String[] permissions = {
                Manifest.permission.POST_NOTIFICATIONS
        };
        ActivityCompat.requestPermissions(this, permissions, 123);
    }
}