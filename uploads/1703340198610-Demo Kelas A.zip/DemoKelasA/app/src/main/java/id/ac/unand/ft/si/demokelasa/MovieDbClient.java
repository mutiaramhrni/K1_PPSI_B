package id.ac.unand.ft.si.demokelasa;

import id.ac.unand.ft.si.demokelasa.entity.MovieListResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface MovieDbClient {

    @GET("/3/movie/now_playing")
    Call<MovieListResponse> getNowPlayingMovies(@Query("api_key") String api_key);

}
