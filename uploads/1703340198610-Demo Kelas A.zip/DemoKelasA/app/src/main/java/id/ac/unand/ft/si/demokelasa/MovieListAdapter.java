package id.ac.unand.ft.si.demokelasa;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import id.ac.unand.ft.si.demokelasa.entity.ResultsItem;

public class MovieListAdapter extends RecyclerView.Adapter<MovieListAdapter.ViewHolder> {

    private List<ResultsItem> listMovie;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textJudul;
        private TextView textRating;
        private ImageView imgPoster;

        public ViewHolder(View view) {
            super(view);
            textJudul = view.findViewById(R.id.text_judul);
            textRating = view.findViewById(R.id.text_rating);
            imgPoster = view.findViewById(R.id.img_poster);
        }

        public void setMovie(ResultsItem resultsItem){
            textJudul.setText(resultsItem.getTitle());
            textRating.setText(resultsItem.getVoteAverage().toString());

            String url = "https://image.tmdb.org/t/p/w300" + resultsItem.getPosterPath();
//            Glide.with(imgPoster.getContext())
//                    .load(url)
//                    .into(imgPoster);
            Picasso.get()
                    .load(url)
                    .into(imgPoster);
        }

    }

    public MovieListAdapter(){
        listMovie = new ArrayList<>();
    }

    public MovieListAdapter(List<ResultsItem> listMovie) {
        this.listMovie = listMovie;
    }

    public void setListMovie(List<ResultsItem> listMovie){
        this.listMovie = listMovie;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_movie, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        ResultsItem movieEntity = listMovie.get(position);
        viewHolder.setMovie(movieEntity);
    }

    @Override
    public int getItemCount() {
        return listMovie.size();
    }
}
